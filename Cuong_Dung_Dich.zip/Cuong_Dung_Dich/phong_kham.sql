-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 21, 2020 lúc 04:44 AM
-- Phiên bản máy phục vụ: 10.4.8-MariaDB
-- Phiên bản PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `phong_kham`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `benh_nhan`
--

CREATE TABLE `benh_nhan` (
  `ID_Benh_Nhan` int(10) UNSIGNED NOT NULL,
  `TenBN` varchar(50) NOT NULL,
  `SDT` int(11) NOT NULL,
  `DiaChi` varchar(100) NOT NULL,
  `GioiTinh` varchar(10) NOT NULL,
  `NgaySinh` varchar(100) NOT NULL,
  `loaidv` varchar(225) NOT NULL,
  `trang_thai` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `benh_nhan`
--

INSERT INTO `benh_nhan` (`ID_Benh_Nhan`, `TenBN`, `SDT`, `DiaChi`, `GioiTinh`, `NgaySinh`, `loaidv`, `trang_thai`) VALUES
(6, 'cuong', 1698273212, '09 nguyen an ninh', 'nam', '1-1-1997', 'thuốc', 1),
(7, 'cuong', 901901546, 'buon ma thuot', 'nam', '1-1-1997', 'thuthuat', 1),
(8, 'lộc', 1698273212, 'nguyen an ninh', 'nam', '09-01-1997', 'khambenh', 1),
(9, 'loc 02', 9019015, '07 adua', 'Nam', '01-01-1990', 'kính', 0),
(10, 'loc 03', 9019015, '07 adua', 'Nam', '01-01-1990', '', 0),
(11, 'cuong02', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', '', 0),
(12, 'cuong12345', 9876543, '12 lê duẫn', 'Nam', '01-01-1990', '', 0),
(13, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', 'kính', 0),
(14, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', 'thuốc', 0),
(15, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', '', 0),
(19, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', '', 0),
(20, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', '', 0),
(21, 'cuonge', 9019015, '12 lê duẫn', 'Nam', '01-01-1990', 'thuthuat', 0),
(22, 'cuong02', 9019015, '07 adua', 'Nam', '01-01-1990', '', 0),
(23, 'cuong02', 9019015, '07 adua', 'Nam', '01-01-1990', '', 0),
(24, 'cuong123', 968698698, '07 adua', 'Nam', '01-01-1990', 'thuốc', 0),
(25, 'cuong123', 968698698, '07 adua', 'Nam', '01-01-1990', '', 0),
(26, 'cuong123', 968698698, '07 adua', 'Nam', '01-01-1990', '', 0),
(28, 'pham duc hoang', 901901546, '27 leduan', 'Nam', '17-12-1997', '', 0),
(30, 'pham duc hoang 2', 9019015, '07 adua', 'Nam', '20-11-1999', '', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_sach_thuoc`
--

CREATE TABLE `danh_sach_thuoc` (
  `ID_DS` int(10) NOT NULL,
  `ID_Loai` int(10) NOT NULL,
  `So_Luong` int(100) NOT NULL,
  `ID_Don_Kham` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `danh_sach_thuoc`
--

INSERT INTO `danh_sach_thuoc` (`ID_DS`, `ID_Loai`, `So_Luong`, `ID_Don_Kham`) VALUES
(1, 3, 10, 1),
(2, 3, 2, 2),
(3, 2, 10, 2),
(4, 3, 7, 2),
(5, 6, 1, 2),
(6, 6, 1, 2),
(7, 6, 3, 2),
(8, 8, 3, 2),
(9, 5, 1, 2),
(10, 10, 1, 2),
(11, 7, 1, 2),
(12, 6, 2, 2),
(13, 7, 1, 2),
(14, 6, 1, 2),
(15, 6, 2, 2),
(16, 7, 2, 2),
(17, 8, 3, 2),
(18, 7, 2, 2),
(19, 9, 2, 2),
(20, 6, 2, 2),
(21, 6, 1, 2),
(22, 6, 2, 2),
(23, 10, 1, 2),
(24, 10, 3, 2),
(25, 6, 1, 2),
(26, 6, 1, 2),
(27, 6, 1, 2),
(28, 6, 1, 2),
(29, 6, 1, 2),
(30, 6, 1, 2),
(31, 6, 3, 2),
(32, 9, 2, 2),
(33, 6, 3, 2),
(34, 9, 4, 2),
(35, 5, 3, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dich_vu`
--

CREATE TABLE `dich_vu` (
  `ID_Dich_Vu` int(10) UNSIGNED NOT NULL,
  `Ten` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `dich_vu`
--

INSERT INTO `dich_vu` (`ID_Dich_Vu`, `Ten`) VALUES
(1, 'Khám Bệnh'),
(2, 'Thủ Thuật'),
(3, 'Thuốc'),
(4, 'Kính');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `don_thuoc`
--

CREATE TABLE `don_thuoc` (
  `ID_Don_Kham` int(100) UNSIGNED NOT NULL,
  `TenChanDoan` varchar(255) NOT NULL,
  `ID_Benh_Nhan` int(100) NOT NULL,
  `Tai_Kham` varchar(255) NOT NULL,
  `GhiChu` varchar(255) NOT NULL,
  `Don_Mau` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `don_thuoc`
--

INSERT INTO `don_thuoc` (`ID_Don_Kham`, `TenChanDoan`, `ID_Benh_Nhan`, `Tai_Kham`, `GhiChu`, `Don_Mau`) VALUES
(1, 'gảy tay', 1, 'không', '', '1'),
(2, 'Loét Dạ Dày', 1, '', '', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ds_dich_vu`
--

CREATE TABLE `ds_dich_vu` (
  `ID_DSDV` int(100) UNSIGNED NOT NULL,
  `ID_Don_Kham` int(100) NOT NULL,
  `ID_Dich_Vu` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `ds_dich_vu`
--

INSERT INTO `ds_dich_vu` (`ID_DSDV`, `ID_Don_Kham`, `ID_Dich_Vu`) VALUES
(1, 1, 2),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_dv`
--

CREATE TABLE `loai_dv` (
  `ID_Loai` int(10) UNSIGNED NOT NULL,
  `IDTheLoai` int(10) UNSIGNED NOT NULL,
  `TenDV` varchar(225) CHARACTER SET utf8 NOT NULL,
  `Gia_Nhap` int(100) NOT NULL,
  `Gia_Ban` int(100) NOT NULL,
  `Uu_Dai` int(100) NOT NULL,
  `Don_Vi` enum('vĩ','chiếc','viên','ống','chai') NOT NULL,
  `Cach_Dung` varchar(225) NOT NULL,
  `So_Luong_Nhap` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `loai_dv`
--

INSERT INTO `loai_dv` (`ID_Loai`, `IDTheLoai`, `TenDV`, `Gia_Nhap`, `Gia_Ban`, `Uu_Dai`, `Don_Vi`, `Cach_Dung`, `So_Luong_Nhap`) VALUES
(1, 1, 'khám Tại Nhà', 0, 20000, 0, '', '', 40),
(2, 1, 'Khám Tại Phòng Khám', 0, 40000, 0, '', '', 40),
(3, 2, 'Phẩu Thuật', 0, 20000, 0, '', '', 40),
(4, 2, 'Khúc Xạ', 0, 0, 0, '', '', 40),
(5, 3, 'Nước muối', 0, 20000, 10, '', 'uống liên tục', 40),
(6, 3, 'vitamin', 0, 20000, 30, '', 'sang chiêu 5 viên', 40),
(7, 4, 'kính đen', 0, 40000, 20, 'chiếc', 'đeo bình thường', 40),
(8, 4, 'kính mát', 0, 60000, 0, 'chiếc', 'không nắng mới được đeo', 40),
(9, 3, 'panadol', 1000, 20000, 10, 'vĩ', 'sáng chiều 1 viên', 40),
(10, 3, 'tiphi', 1000, 20000, 30, 'ống', 'sáng chiều 1 viên', 40);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `taikhoan`
--

CREATE TABLE `taikhoan` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `quyen` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `taikhoan`
--

INSERT INTO `taikhoan` (`id`, `user_name`, `password`, `quyen`) VALUES
(1, 'cuong000', '00000', 1);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `benh_nhan`
--
ALTER TABLE `benh_nhan`
  ADD PRIMARY KEY (`ID_Benh_Nhan`);

--
-- Chỉ mục cho bảng `danh_sach_thuoc`
--
ALTER TABLE `danh_sach_thuoc`
  ADD PRIMARY KEY (`ID_DS`);

--
-- Chỉ mục cho bảng `dich_vu`
--
ALTER TABLE `dich_vu`
  ADD PRIMARY KEY (`ID_Dich_Vu`);

--
-- Chỉ mục cho bảng `don_thuoc`
--
ALTER TABLE `don_thuoc`
  ADD PRIMARY KEY (`ID_Don_Kham`);

--
-- Chỉ mục cho bảng `ds_dich_vu`
--
ALTER TABLE `ds_dich_vu`
  ADD PRIMARY KEY (`ID_DSDV`);

--
-- Chỉ mục cho bảng `loai_dv`
--
ALTER TABLE `loai_dv`
  ADD PRIMARY KEY (`ID_Loai`),
  ADD KEY `FK_DV` (`IDTheLoai`);

--
-- Chỉ mục cho bảng `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `benh_nhan`
--
ALTER TABLE `benh_nhan`
  MODIFY `ID_Benh_Nhan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT cho bảng `danh_sach_thuoc`
--
ALTER TABLE `danh_sach_thuoc`
  MODIFY `ID_DS` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT cho bảng `dich_vu`
--
ALTER TABLE `dich_vu`
  MODIFY `ID_Dich_Vu` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `don_thuoc`
--
ALTER TABLE `don_thuoc`
  MODIFY `ID_Don_Kham` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `ds_dich_vu`
--
ALTER TABLE `ds_dich_vu`
  MODIFY `ID_DSDV` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `loai_dv`
--
ALTER TABLE `loai_dv`
  MODIFY `ID_Loai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT cho bảng `taikhoan`
--
ALTER TABLE `taikhoan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `loai_dv`
--
ALTER TABLE `loai_dv`
  ADD CONSTRAINT `FK_DV` FOREIGN KEY (`IDTheLoai`) REFERENCES `dich_vu` (`ID_Dich_Vu`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
