<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link rel="stylesheet" type="text/css" href="./public/css/hoadon.css">
</head>
<body onload="window.print();">
<div id="page" class="page">
    <div class="header">
        <div class="logo"><img src="./public/image/logo.png" style="width: 60px;height: 50px;" /></div>
        <div class="company">Phòng Khám X</div>
    </div>
  <br/>
  <?php
  include 'connet.php';
  $dsid = json_decode(stripslashes($_POST['dsid']));
  $dssl = json_decode(stripslashes($_POST['dssl']));

  for ($i = 0; $i < count($dsid); $i++) {
     $sql = "INSERT INTO `danh_sach_thuoc` ( `ID_Loai`, `So_Luong`, `ID_Don_Kham`) VALUES ( '".$dsid[$i]."', '".$dssl[$i]."', '2')";
     $query = mysqli_query($conn,$sql);
  }
  ?>
  <div class="title">
        HÓA ĐƠN THANH TOÁN
        <br/>
        -------oOo-------
  </div>
  <br/>
  <br/>
  <table class="TableData">
    <tr>
      <th>STT</th>
      <th>Tên Thuốc</th>
      <th>Cách Dùng</th>
      <th>Đơn Giá</th>
      <th>Số Lượng</th>
      <th>Ưu Đãi</th>
      <th>Thành tiền</th>
    </tr>
   
  
    <?php
    $tong = 0;
      for ($i = 0; $i < count($dsid); $i++) {
     $sql = "SELECT * FROM loai_dv where ID_Loai='".$dsid[$i]."'";
     $query = mysqli_query($conn,$sql);
     $row = mysqli_fetch_array($query);
     $thanhtien = $row['Gia_Ban']*$dssl[$i];
     $thanhtien2 = $thanhtien/$row['Uu_Dai'];
     echo "<tr>";
     echo "<td>".$i."</td>";
     echo "<td>".$row['TenDV']."</td>";
     echo "<td>".$row['Cach_Dung']."</td>";
     echo "<td>".$row['Gia_Ban']."</td>";
     echo "<td>".$dssl[$i]."</td>";
     echo "<td>".$row['Uu_Dai']."</td>";
     echo "<td>".$thanhtien2.".VND </td>";
     echo "</tr>";
     $tong += $thanhtien2;
  }
    ?>
    
    <tr>
      <td colspan="4" class="tong">Tổng cộng</td>
      <td class="cotSo"><?php echo $tong?>.VND</td>
    </tr>
  </table>
  <div class="footer-left"><br/>
    Khách hàng </div>
  <div class="footer-right"><br/>
    Nhân viên </div>
</div>
</body>
</html>