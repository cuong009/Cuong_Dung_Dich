<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
</head>
<body>

</body>
</html>
<?php
// Array with names
    
$conn = mysqli_connect('localhost', 'root', '', 'phong_kham') or die ('Không thể kết nối tới database');
$sql="SELECT * from loai_dv where ID_Loai='".$_POST['idthuoc']."'";
//$sql="SELECT * FROM Don_Thuoc where TenChanDoan like '".$q."%' ";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($result)) {
  
   echo "<tr data-id='".$_POST['idthuoc']."'>";
   echo "<td>".$row['TenDV']."</td>";
    echo "<td>".$row['Cach_Dung']."</td>";
     echo "<td>".$_POST['soluongthuoc']."</td>"   ; 
   echo "</tr>";
}