<?php
	include '../connet.php';
	$thaotac = $_GET['thaotac'];
	echo $_GET['idbn'];
	switch ($thaotac) {
		case 1:
			$sql = "DELETE FROm benh_nhan where ID_Benh_Nhan='".$_GET['idbn']."'";
			$query = mysqli_query($conn,$sql);
			break;
	}
?>