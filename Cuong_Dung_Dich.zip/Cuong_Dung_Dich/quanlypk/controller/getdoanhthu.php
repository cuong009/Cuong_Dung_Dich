<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
</head>
<body>

</body>
</html>
<?php
// Array with names
    

$conn = mysqli_connect('localhost', 'root', '', 'phong_kham') or die ('Không thể kết nối tới database');
$sql="SELECT A.TenDV,B.So_Luong,A.Gia_Nhap,A.Gia_Ban,A.So_Luong_Nhap FROM loai_dv A INNER JOIN danh_sach_thuoc B on A.IDTheLoai=B.ID_Loai inner JOIN don_thuoc C on B.ID_Don_Kham=C.ID_Don_Kham     ";
$result = mysqli_query($conn,$sql);
echo "<table id='myTable'>
<tr>
<th>Loại Dich Vụ</th>
<th>Số Lượng Đã Bán</th>
<th>Doanh Thu</th>
<th>Số Lượng Còn lại</th>
</tr>
";

$tong = 0;
$tongsl =0;
while($row = mysqli_fetch_array($result)) {
  $slconlai = $row['So_Luong_Nhap']-$row['So_Luong'];
  $doanhthu = $row['Gia_Ban']-$row['Gia_Nhap'];
  $doanhthu2 = $row['So_Luong']*$doanhthu;
  $tong += $doanhthu2;
  $tongsl += $row['So_Luong'];
  echo '<tr">';
  echo "<td>" . $row['TenDV'] . "</td>";
  echo "<td>" . $row['So_Luong'] . "</td>";
  echo "<td>" . $doanhthu2 . "</td>";
  echo "<td>" . $slconlai . "</td>";
  //echo "<td>" . $row['NgaySinh'] . "</td>";
  echo "</tr>";
}
echo "<tr>";
echo "<td>Tổng</td>";
echo "<td> " . $tongsl . "</td>";
echo "<td> " . $tong . ".VND</td>";
echo "</td>";
echo "</table>";

// lookup all hints from array if $q is different from ""
// if ($q !== "") {
//   $q = strtolower($q);
//   $len=strlen($q);
//   foreach($ten as $name) {
//     if (stristr($q, substr($name, 0, $len))) {
//       if ($hint === "") {
//         $hint = $name;
//       } else {
//         $hint .= ", $name";
//       }
//     }
//   }
// }

// Output "no suggestion" if no hint was found or output correct values

?>