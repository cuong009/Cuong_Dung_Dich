<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
</head>
<body>

</body>
</html>
<?php
// Array with names
    
$q = $_REQUEST["q"];
$conn = mysqli_connect('localhost', 'root', '', 'phong_kham') or die ('Không thể kết nối tới database');
$sql="SELECT C.TenChanDoan,C.GhiChu,A.TenDV,A.Gia_Ban,A.Cach_Dung,A.Don_Vi,B.So_Luong FROM loai_dv A INNER JOIN danh_sach_thuoc B on A.IDTheLoai=B.ID_Loai inner JOIN don_thuoc C on B.ID_Don_Kham=C.ID_Don_Kham where TenChanDoan like '".$q."%'";
//$sql="SELECT * FROM Don_Thuoc where TenChanDoan like '".$q."%' ";
$result = mysqli_query($conn,$sql);
echo "<table id='myTable'>
<tr>
<th>Tên Thuốc</th>
<th>Số Lượng</th>
<th>Cách Dùng</th>
<th>Giá Bán</th>
<th>Đơn Vị</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo '<tr onclick="myFunction(this)">';

  
   echo "<td>" . $row['TenDV'] . "</td>";
   echo "<td>" . $row['So_Luong'] . "</td>";
   echo "<td>" . $row['Cach_Dung'] . "</td>";
   echo "<td>" . $row['Gia_Ban'] . "</td>";
   echo "<td>" . $row['Don_Vi'] . "</td>";
       
  echo "</tr>";
}
echo "</table>";