<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
</head>
<body>

</body>
</html>
<?php
// Array with names
    
$q = $_REQUEST["q"];
$conn = mysqli_connect('localhost', 'root', '', 'phong_kham') or die ('Không thể kết nối tới database');
$sql="SELECT * FROM benh_nhan where TenBN like '".$q."%' or SDT like '".$q."%'";
$result = mysqli_query($conn,$sql);
echo "<table id='myTable'>
<tr>
<th>ID</th>
<th>Tên Bệnh Nhân</th>
<th>Số Điện Thoại</th>
<th>Địa Chỉ</th>
<th>Ngày Sinh</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo '<tr onclick="myFunction(this)">';
  echo "<td>" . $row['ID_Benh_Nhan'] . "</td>";
  echo "<td>" . $row['TenBN'] . "</td>";
  echo "<td>" . $row['SDT'] . "</td>";
  echo "<td>" . $row['DiaChi'] . "</td>";
  echo "<td>" . $row['NgaySinh'] . "</td>";
  echo "</tr>";
}
echo "</table>";

// lookup all hints from array if $q is different from ""
// if ($q !== "") {
//   $q = strtolower($q);
//   $len=strlen($q);
//   foreach($ten as $name) {
//     if (stristr($q, substr($name, 0, $len))) {
//       if ($hint === "") {
//         $hint = $name;
//       } else {
//         $hint .= ", $name";
//       }
//     }
//   }
// }

// Output "no suggestion" if no hint was found or output correct values

?>