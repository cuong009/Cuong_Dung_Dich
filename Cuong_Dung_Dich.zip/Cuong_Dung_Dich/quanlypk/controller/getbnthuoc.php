<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
</head>
<body>
<?php
include '../connet.php';
$sql="SELECT * FROM benh_nhan  where loaidv='thuốc'";
$result = mysqli_query($conn,$sql);

echo "<table id='myTable'>
<tr>
<th>ID</th>
<th>Tên Bệnh Nhân</th>
<th>Số Điện Thoại</th>
<th>Địa Chỉ</th>
<th>Ngày Sinh</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['ID_Benh_Nhan'] . "</td>";
  echo "<td>" . $row['TenBN'] . "</td>";
  echo "<td>" . $row['SDT'] . "</td>";
  echo "<td>" . $row['DiaChi'] . "</td>";
  echo "<td>" . $row['NgaySinh'] . "</td>";
  echo "</tr>";
}
echo "</table>";
mysqli_close($conn);
?>
</body>
</html>