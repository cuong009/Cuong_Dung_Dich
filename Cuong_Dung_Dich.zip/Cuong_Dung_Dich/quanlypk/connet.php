<?php
	$conn = mysqli_connect('localhost', 'root', '', 'phong_kham') or die ('Không thể kết nối tới database');
?>