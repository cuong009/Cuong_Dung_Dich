<?php
  session_start();
  if(!isset($_SESSION['username']))
  {
    header("location:dangnhap.php");
  }else{
    ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Phòng Khám X</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="public/css/shop-homepage.css" rel="stylesheet">
    <link href="public/css/my.css" rel="stylesheet">
    <link href="public/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" />
    <link href="public/css/fontawesom/css/font-awesome.min.css" rel="stylesheet"/>

    <style type="text/css">
        
        #sticky{
            position: sticky;
            top: 53px;
        }

         table, th, td{
            border:1px solid #ccc;
        }
        table{
            border-collapse:collapse;
            width:100%;
        }
        th, td{
            text-align:left;
            padding:10px;
        }
        tr:hover{
            background-color:#ddd;
            cursor:pointer;
        }       
        #sticky{
            position: sticky;
            top: 53px;
        }
    </style>
   
</head>

<body>
   
    <!-- Navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background: rgb(51,82,183);">
        <div class="container">
          
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="index.php"><i class="fa fa-home"></i>  Trang Chủ</a>
            </div>
          
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="#">Liên hệ</a>
                    </li>
                </ul>

                <form class="navbar-form navbar-left" role="search">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search">
                    </div>
                    <button type="submit" class="btn btn-default">Tìm Kiếm</button>
                </form>

                <ul class="nav navbar-nav pull-right">
                   
                     <?php 
                        if(isset($_SESSION['username']))
                        {
                            ?>
                            <li>
                                <a>
                                    <span class ="glyphicon glyphicon-user"></span>
                                   <?php echo $_SESSION['username'];  ?>
                                </a>
                            </li>
                          <?php
                            }
                           ?>  
                          
                         <li>
                            <a href="dangxuat.php">Đăng Xuất</a>
                        </li>          
                </ul>
            </div>        
        </div>
        
    </nav>

     <div id="main" style=" background: white;width: 1160px;margin: 0 auto;padding: 0; border:1px solid #ccc;-moz-box-shadow: 0px 0px 15px 0px #666;-webkit-box-shadow: 0px 0px 15px 0px #666;box-shadow: 0px 0px 15px 0px #666;" >   
    <div class="container">


        <div class="space20"></div>


        <div class="row main-left" >
          

            <div class="col-md-9">
                <div class="panel panel-default" style="width: 1100px;">
                    <div class="panel-heading" style="background-color:#337AB7; color:white;width: 1100px;" >
                        <h2 style="">Đơn Khám <i class="fa fa-book-open"></i> </h2>
                    </div>

                    <div class="panel-body" >
                        <!-- item -->
                        
                        <form>
                            <div class="form-group">
                            
                            <form action="" onsubmit="return false">
                                  <label for="inputAddress">Tên Bệnh Nhân</label>
                                   <input list="tkbn" name="tkbn" style="margin-left: 30px;">
                                    <datalist id="tkbn">
                                      <?php
                                    include 'connet.php';
                                    $sql="select * from benh_nhan";
                                    $query = mysqli_query($conn,$sql);
                                    while ($row = mysqli_fetch_array($query)) {
                                      echo "<option value='".$row['TenBN']."' name='".$row['TenBN']."'  data-id='".$row['ID_Benh_Nhan']."'>";
                                    }
                                    ?>
                                      
                                      
                                    </datalist>
                                  
                                  
                                </form>
                          </div>
                          <div class="form-group">
                            <form action="" onsubmit="return false">
                                  <label for="inputAddress">Chẩn Đoán Bệnh</label>
                                   <input list="tenbenh" name="tenbenh" style="margin-left: 20px;">
                                    <datalist id="tenbenh" >
                                      <?php
                                    include 'connet.php';
                                    $sql="select * from don_thuoc";
                                    $query = mysqli_query($conn,$sql);
                                    while ($row = mysqli_fetch_array($query)) {
                                      echo "<option value='".$row['TenChanDoan']."' name='".$row['TenChanDoan']."'  data-id='".$row['ID_Don_Kham']."'>";
                                    }
                                    ?>
                                      
                                      
                                    </datalist>
                                  
                                  
                                </form>
                          </div>
                          <div class="form-group">
                            <form action="" onsubmit="return false">
                                  <label for="thuoc">Chọn Thuốc</label>
                                   <input list="dsthuoc" name="thuoc" style="margin-left: 50px;">
                                    <datalist id="dsthuoc">
                                      <?php
                                    include 'connet.php';
                                    $sql="select TenDV,ID_Loai from loai_dv where IDTheLoai='3' or IDTheLoai='4'";
                                    $query = mysqli_query($conn,$sql);
                                    while ($row = mysqli_fetch_array($query)) {
                                      echo "<option value='".$row['TenDV']."' name='".$row['TenDV']."'  data-id='".$row['ID_Loai']."'>";
                                    }
                                    ?>
                                      
                                      
                                    </datalist>
                                  <input type="number" min="1" max="20" name="soluong" value="1" id="soluongthuoc">
                                  <button onclick="Themthuoc('dsthuoc')" type="button">Thêm Thuốc</button>
                                  
                                </form>
                               
                          </div>

                          
                        <!-- end item -->
                          <div class="form-row">
                            <div class="form-group col-md-6">
                              <label for="inputCity">Ghi Chú</label>
                              <input type="text" class="form-control" id="inputCity">
                            </div>
                            <div class="form-group col-md-4">
                              <label for="inputState">Chọn Dịch Vụ</label>
                              <select id="inputState" class="form-control">
                                <option selected>Khám Bệnh</option>
                                <option>Thủ Thuật</option>
                                <option>Thuốc</option>
                                <option>Kính</option>
                              </select>
                            </div>
                            <div class="form-group col-md-2">
                              <label for="inputZip">Zip</label>
                              <input type="text" class="form-control" id="inputZip">
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" id="gridCheck">
                              <label class="form-check-label" for="gridCheck">
                                Lưu Đơn Mẫu
                              </label>
                            </div>
                          </div>
                          <form action="" method="POST">
                            
                              <table style="width:100%" id="nhapthuoc">
                              <tr>
                                <th>Thuốc</th>
                                <th>Cách Dùng</th>
                                <th>Số Lượng</th>
                              </tr>
                              
                            </table>
                         
                          
                         
                         </form>
                          <button type="submit" class="btn btn-primary" onclick="chuyendon()">Lưu Đơn</button>
                        </form>
                        <!-- end item -->

                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- end Page Content -->

    <!-- Footer -->
    <hr>
    <footer>
        
    </footer>
    </div>
     <script>
                                function showHint(str) {
                                    if (str.length == 0) {
                                      document.getElementById("txtHint").innerHTML = "";
                                      return;
                                    } else {
                                      var xmlhttp = new XMLHttpRequest();
                                      xmlhttp.onreadystatechange = function() {
                                        if (this.readyState == 4 && this.status == 200) {
                                          document.getElementById("txtHint").innerHTML = this.responseText;
                                        }
                                      }
                                      xmlhttp.open("GET", "controller/getbntk.php?q="+str, true);
                                      xmlhttp.send();
                                    }
                                  }
                                function Themthuoc(listid){
                                  var listObj = document.querySelector('input[list='+listid+']');
                                  var datalist = document.getElementById(listid);
                                  var idthuoc = datalist.options.namedItem(listObj.value).attributes['data-id'].value; 
                                  var soluongthuoc = document.getElementById('soluongthuoc').value;

                                  var formData = new FormData();
                                  formData.append('idthuoc',idthuoc);
                                  formData.append('soluongthuoc',soluongthuoc);
                                
                                  var xmlhttp = new XMLHttpRequest();
                                  xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                       document.getElementById("nhapthuoc").innerHTML+=this.responseText;
                                    }
                                  };
                                  xmlhttp.open("POST","controller/getthuoc.php",true);
                                  xmlhttp.send(formData);
                                 
                                        }
                                        function chuyendon(){
                                          var rows = document.getElementById("nhapthuoc").rows;
                                          var dsid = [];
                                          var dssl = [];
                                          for (var i = 1; i < rows.length ; i++) {
                                            dsid.push(rows[i].attributes['data-id'].value);
                                            dssl.push(rows[i].cells[2].innerHTML);
                                          }
                                          console.log(dssl);
                                        var jsonid = JSON.stringify(dsid);
                                        var jsonsl = JSON.stringify(dssl);
                                        var formData = new FormData();
                                        formData.append('dsid',jsonid);
                                        formData.append('dssl',jsonsl);
                                      
                                        var xmlhttp = new XMLHttpRequest();
                                        xmlhttp.onreadystatechange = function() {
                                          if (this.readyState == 4 && this.status == 200) {
                                              document.getElementsByTagName("body")[0].innerHTML = this.responseText;
                                          }
                                        };
                                        xmlhttp.open("POST","hoadon.php",true);
                                        xmlhttp.send(formData);
                                         }
                                </script>
                                <script type="text/javascript">
                                  function showdonmau(str) {
                                  if (str.length == 0) {
                                    document.getElementById("txtHint").innerHTML = "";
                                    return;
                                  } else {
                                    var xmlhttp = new XMLHttpRequest();
                                    xmlhttp.onreadystatechange = function() {
                                      if (this.readyState == 4 && this.status == 200) {
                                        document.getElementById("txtHint").innerHTML = this.responseText;
                                      }
                                    }
                                    xmlhttp.open("GET", "controller/getdonmau.php?q="+str, true);
                                    xmlhttp.send();
                                  }
                                }    
                                 </script>
    <!-- end Footer -->
    <!-- jQuery -->
    <script src="public/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="public/js/bootstrap.min.js"></script>
    <script src="public/js/my.js"></script>
</body>
</html>
<?php
  }

?>
