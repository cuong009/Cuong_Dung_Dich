<?php
    require_once("connet.php");
    $thaotac = $_POST['thaotac'];
    $idbn = $_POST['idbn'];
    if(isset($_POST['submit']))
    {
        if(empty($_POST['HoTen']) or empty($_POST['sdt']) or empty($_POST['diachi']))
        {
             $error = "Thông Tin Bệnh Nhân !!";
        }else{
            $HoTen = $_POST['HoTen'];
            $sdt = $_POST['sdt'];
            $diachi = $_POST['diachi'];
            $nam = $_POST['ngay'].'-'.$_POST['thang'].'-'.$_POST['nam'];
            
            $gioitinh =$_POST['gioitinh'];
            if($thaotac='sua')
            {
                $sql ="INSERT INTO benh_nhan( `TenBN`, `SDT`, `DiaChi`, `GioiTinh`, `NgaySinh`) VALUES ( '".$HoTen."', '".$sdt."', '".$diachi."', '".$gioitinh."', '".$nam."')";
                $query = mysqli_query($conn,$sql);
                $message = "bạn đã thêm bệnh nhân";

                
            }else{
                $sql ="UPDATE benh_nhan( `TenBN`, `SDT`, `DiaChi`, `GioiTinh`, `NgaySinh`) VALUES ( '".$HoTen."', '".$sdt."', '".$diachi."', '".$gioitinh."', '".$nam."') where ID_Benh_Nhan='".$idbn."'";
                $query = mysqli_query($conn,$sql);
                $message = "bạn đã Sửa Thông Tin bệnh nhân";
            
        }
            
            echo "<script type='text/javascript'>alert('$message');
                    window.location.assign('index.php');
            </script> ";
            //header("location:index.php");

            
        }
    }
    if(isset($_POST['quaylai']))
    {
        header("location:index.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Thêm Bệnh Nhân</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="public/css/DangNhap.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    	<div id="wrap">
        <header>
            <div class="container">
                <h3>QUẢN LÝ PHÒNG KHÁM</h3>
            </div>
        </header>
        <main>
            <div class="container">
            <div class="login-form">
                <form action="" method="POST">
                    <?php
                        if(isset($_POST['thaotac']))
                        {
                            echo "<h1>Sửa Thông Tin Bệnh Nhân </h1>";
                        }else{
                            echo "<h1>Thêm Bệnh Nhân mới </h1>";
                        }
                    ?>
                    

                    <div class="input-box">
                        <i ></i>
                        <input type="text" value="<?php if(isset($_POST['Ten'])){echo $_POST['Ten'];}?>" placeholder="Nhập Họ Tên" name="HoTen">
                    </div>
                    <div class="input-box">
                        <i ></i>
                        <input type="text" placeholder="Nhập Số Điện Thoại" name="sdt" value="<?php if(isset($_POST['sdt'])){echo $_POST['sdt'];}?>">
                    </div>
                   
                    <div class="input-box">
                        <i ></i>
                        <input type="text" placeholder="Địa Chỉ" name="diachi" value="<?php if(isset($_POST['diachi'])){echo $_POST['diachi'];}?>">
                    </div>
                    <div style="padding-top: 15px;padding-bottom: 15px;">
                       Giớ Tính :
                        <input type="radio" name="gioitinh" checked value="Nam">Nam
                        <input type="radio" name="gioitinh" value="Nữ">Nữ<br/>
                    </div>
                	  <div class="input-box">
                        <i ></i>
                         Ngày:
                        <select name="ngay">
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option>

                        </select>
                         Tháng:
                        <select name="thang">
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option valsue="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option valsue="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option valsue="12">12</option>
                        </select>
                        Năm :
                        <select name="nam">
						<option value="1990">1990</option>
						<option value="1991">1991</option>
						<option value="1992">1992</option>
						<option valsue="1993">1993</option>
						<option value="1994">1994</option>
						<option value="1995">1995</option>
						<option value="1996">1996</option>
						<option valsue="1997">1997</option>
						<option value="1998">1998</option>
						<option value="1999">1999</option>
						<option value="2000">2000</option>
						<option valsue="2001">2001</option>
						</select>
                       
                    </div>
          
                    <div class="btn-box">
                        <input type="submit" name="submit" value="Thêm" style="width: 80px;height: 40px; border-radius: 10px;background-color: rgb(128,128,128,0.2);cursor: pointer;" >
                        <input type="submit" name="quaylai" value="Quay Lại" style="width: 80px;height: 40px; border-radius: 10px;background-color: rgb(128,128,128,0.2);cursor: pointer;" >
                    </div>
                   
                </form>
            </div>
            </div>
               <?php
                    if(isset($error))
                    {
                        echo '<p style="color:red;margin-left:320px;">'.$error.'<p>';
                    }
                ?>
        </main>
        <footer>
            
        </footer>
    </div>
    </body>
</html>