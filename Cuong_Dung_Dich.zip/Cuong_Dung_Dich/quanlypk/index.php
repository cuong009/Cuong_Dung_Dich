<?php
  session_start();
  if(!isset($_SESSION['username']))
  {
    header("location:dangnhap.php");
  }else{
    ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Phòng Khám X</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="public/css/shop-homepage.css" rel="stylesheet">
    <link href="public/css/my.css" rel="stylesheet">
    <link href="public/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" />
    <link href="public/css/fontawesom/css/font-awesome.min.css" rel="stylesheet"/>

    <style type="text/css">
        
        #sticky{
            position: sticky;
            top: 53px;
        }
        table {
  width: 100%;
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}


/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}

    </style>
</head>

<body>
   
    <!-- Navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background: rgb(51,82,183);">
        <div class="container">
          
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="index.php"><i class="fa fa-home"></i>  Trang Chủ</a>
            </div>
          
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="#">Liên hệ</a>
                    </li>
                </ul>

                <form class="navbar-form navbar-left" role="search">

               
                  

                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search" id="fname" name="fname" onkeyup="showHint(this.value)">
                    </div>
                    <button type="submit" class="btn btn-default">Tìm Kiếm</button>
                    
                </form>

                <ul class="nav navbar-nav pull-right">
                   
                    <?php 
                        if(isset($_SESSION['username']))
                        {
                            ?>
                            <li>
                                <a>
                                    <span class ="glyphicon glyphicon-user"></span>
                                   <?php echo $_SESSION['username'];  ?>
                                </a>
                            </li>
                          <?php
                            }
                           ?>  
                          <li>
                            <a href="Luudon.php">Khám Bệnh</a>
                          </li>
                          <li>
                            <a href="thongke.php">Thống Kê</a>
                        </li>  
                         <li>
                            <a href="dangxuat.php">Đăng Xuất</a>
                        </li>     
                                   
                </ul>
            </div>        
        </div>
        
    </nav>

     <div id="main" style=" background: white;width: 1160px;margin: 0 auto;padding: 0; border:1px solid #ccc;-moz-box-shadow: 0px 0px 15px 0px #666;-webkit-box-shadow: 0px 0px 15px 0px #666;box-shadow: 0px 0px 15px 0px #666;" >   
    <div class="container">


        <div class="space20"></div>


        <div class="row main-left" >
          

            <div class="col-md-9">
	            <div class="panel panel-default" style="width: 1100px;">
	            	<div class="panel-heading" style="background-color:#337AB7; color:white;width: 1100px;" >
	            		<h2 style="">Dịch Vụ <i class="fa fa-book-open"></i> </h2>
	            	</div>


                    
                        <form action="">
                            <div class="tab">
                            <input type="button" onclick="showUser(1);" name="" value="Khám Bệnh" class="tablinks">
                            <input type="button" onclick="showUser(2);" name="" value="Thủ Thuật" class="tablinks">
                            <input type="button" onclick="showUser(3);" name="" value="Thuốc" class="tablinks">
                            <input type="button" onclick="showUser(4);" name="" value="Kính" class="tablinks">
                              </div>
                        </form>
                        <br>
                        <div id="txtHint"><b><?php
                            include 'controller/getbn.php';
                        ?></b></div>
                          <form action="" >
                            
                          <a href="benhnhanmoi.php">  <input type="button" onclick="" name="" value="Thêm" class="tablinks"> </a>
                            <input type="button" onclick="deleteRow()" name="" value="Xóa" class="tablinks">
                            <input type="button" onclick="suabn()" name="" value="Sửa" class="tablinks">
                         
                              
                        </form>
                      

	            </div>
        	</div>
        </div>
        <!-- /.row -->
    </div>
    <!-- end Page Content -->

    <!-- Footer -->
    <hr>
    <footer>
        
    </footer>
    </div>
    
    <!-- end Footer -->
    <!-- jQuery -->
    <script src="public/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="public/js/bootstrap.min.js"></script>
    <script src="public/js/my.js"></script>
    <script type="text/javascript" src="public/js/myscr.js"></script>
</body>
</html>
<?php
  }

?>
