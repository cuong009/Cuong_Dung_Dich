                      
                        var vitribn;

                        function myFunction(x) {
                            
                        vitribn=x.rowIndex;
                        
                         }
                         function deleteRow() {
                                if(vitribn){
                                
                               var idbn = document.getElementById("myTable").rows[vitribn].cells[0].innerHTML;
                               var xmlhttp = new XMLHttpRequest();
                               xmlhttp.open("GET","controller/delete.php?thaotac=1&idbn="+idbn,true);
                               xmlhttp.send();
                               document.getElementById("myTable").deleteRow(vitribn);
                                vitribn = '';
                                }
                            }
                          function text(){
                            alert('lolloc');
                          }
                        function showUser(str) {
                            var xmlhttp = new XMLHttpRequest();
                            xmlhttp.onreadystatechange = function() {
                              if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("txtHint").innerHTML = this.responseText;
                              }
                            };
                            switch(str) {
                              case 1:
                                xmlhttp.open("GET","controller/getbn.php",true);
                                break;
                              case 2:
                                xmlhttp.open("GET","controller/getbnkx.php",true);
                                break;
                              case 3:
                                xmlhttp.open("GET","controller/getbnthuoc.php",true);
                                break;
                              case 4:
                                xmlhttp.open("GET","controller/getbnkinh.php",true);
                                break;
                              
                            }
                            xmlhttp.send();
                          }
                        function showHint(str) {
                        if (str.length == 0) {
                          document.getElementById("txtHint").innerHTML = "";
                          return;
                        } else {
                          var xmlhttp = new XMLHttpRequest();
                          xmlhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                              document.getElementById("txtHint").innerHTML = this.responseText;
                            }
                          }
                          xmlhttp.open("GET", "controller/getbntk.php?q="+str, true);
                          xmlhttp.send();
                        }
                      }
                      
                      function suabn()
                      {
                           var idbn = document.getElementById("myTable").rows[vitribn].cells[0].innerHTML;
                           var Ten = document.getElementById("myTable").rows[vitribn].cells[1].innerHTML;
                           var sdt = document.getElementById("myTable").rows[vitribn].cells[2].innerHTML;
                           var diachi = document.getElementById("myTable").rows[vitribn].cells[3].innerHTML;
                          // var gioitinh = document.getElementById("myTable").rows[vitribn].cells[3].innerHTML;
                           //var namsinh = document.getElementById("myTable").rows[vitribn].cells[3].innerHTML;
                          var formData = new FormData();
                          formData.append('idbn',idbn);
                          formData.append('Ten',Ten);
                          formData.append('sdt', sdt);
                          formData.append('diachi', diachi);
                          formData.append('thaotac', 'sua');
                          //formData.append('gioitinh', 'value2');
                          var xmlhttp = new XMLHttpRequest();
                          xmlhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                               document.getElementsByTagName("body")[0].innerHTML = this.responseText;
                            }
                          };
                          xmlhttp.open("POST","benhnhanmoi.php",true);
                          xmlhttp.send(formData);
                          //request.send(formData);
                    }